from django.apps import AppConfig


class RequestConfig(AppConfig):
    name = 'tickMan2age'
    verbose_name = "tickMan2age"
