"""
django-tickMan2age - A Django powered ticket tracker for small enterprise.

templatetags/tickMan2age_staff.py - The is_tickMan2age_staff template filter returns True if the user qualifies as Service Request staff.
"""
import logging
from django.template import Library
from django.db.models import Q

from tickMan2age.decorators import is_tickMan2age_staff


logger = logging.getLogger(__name__)
register = Library()


@register.filter(name='is_tickMan2age_staff')
def tickMan2age_staff(user):
    try:
        return is_tickMan2age_staff(user)
    except Exception as e:
        logger.exception("'tickMan2age_staff' template tag (django-tickMan2age) crashed")
