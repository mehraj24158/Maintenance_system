"""
django-tickMan2age - A Django powered ticket tracker for small enterprise.

templatetags/load_tickMan2age_settings.py - returns the settings as defined in
                                    django-tickMan2age/tickMan2age/settings.py
"""
from django.template import Library
from tickMan2age import settings as tickMan2age_settings_config


def load_tickMan2age_settings(request):
    try:
        return tickMan2age_settings_config
    except Exception as e:
        import sys
        print("'load_tickMan2age_settings' template tag (django-tickMan2age) crashed with following error:",
              file=sys.stderr)
        print(e, file=sys.stderr)
        return ''


register = Library()
register.filter('load_tickMan2age_settings', load_tickMan2age_settings)
