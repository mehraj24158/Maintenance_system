from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin

from tickMan2age.decorators import is_tickMan2age_staff


class MustBeStaffMixin(LoginRequiredMixin, UserPassesTestMixin):
    def test_func(self):
        return is_tickMan2age_staff(self.request.user)
