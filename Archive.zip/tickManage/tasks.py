from celery import task

from .email import process_email

@task()
def tickMan2age_process_email():
    process_email()